#fomat()

# str = "TEST {}".format(10)
# print(str)
# print(type(str))

# charge = 5000
# print("{}만 원".format(charge))
# print("파이썬 열공하여 첫 연봉 {}만 원 만들기 ".format(5000))
# print("{} {} {}".format(3000, 4000, 5000))
# print("{} {} {}".format(1, "문자열", True))
# print("{1} {0} {2}".format(1, "문자열", True))

# #format() IndexError 예외
#
# format_a="{} {}".format(1,2,3,4,5)
# print(format_a)
# format_b="{} {} {}".format(1,2)

# # -----------------------
# # 미니문제
# # -----------------------
# 두개의 값을 입력 받아서 다음 실행 결과가 나오도록 하세요
#
# 사과 1개당 가격: 1000
# 사과 개수 :5
#
# 사과 1개당 가격은 {} 원이고, 총사과판매액수는 {}입니다

# str = "hello world hong"
# print(str.upper())
# print(str.lower())
# print(str.capitalize())
# print(str.title())
# print(" Hello ".strip())
# print(str.replace('h','T'))
# print(str.find("w"))
#
# print(str.startswith("he"))
# print("x" in str)

