# print(True)
# print(False)
# print(10==100)
# print(10!=100)
# x=25
# print(10<x<20)
#
# print("가방"=="가방")
# print("가방"=="오렌지")
# print("가방">="오렌지")
# print("가방"<="오렌지")

# #논리연산자 and(&&) , or(||) ,not(!)
# print(not True)
# print(not False)
# print(True and True)
# print(False and True)
# print(True and False)
# n1 = int(input("n1 >"))
# n2 = int(input("n2 >"))
# print(n1>n2 and n1>20)

# # if
# if False :
#     print("참입니다!-1")
#     print("참입니다!-2")
# print("종료")


#짝홀수 ( %, 끝한자리 , in )
num = input("num >")
ln = int(num[-1])
print(ln)

if ln==2 or ln==4 or ln ==6 or ln==8 or ln==0:
    print("짝수")

if str(ln) in "24680":
    print("짝수")

if ln%2==0:
    print("짝수")

#양음수
# num = int(input("num >"))
# if num>0 :
#     print("양수")
# else :
#     print("음수")

# # ----------------------------------------------------
# // [문제풀기]
# # ----------------------------------------------------
# //입력한 데이터가 3의 배수인 경우 출력하시오
# //
# //절대값을 구하는 프로그램을 작성하시오
# //
# //수를 입력 받아 짝,홀수를 구분하여 출력하시오
# //
# //두수를 입력 받아 큰 수를 출력하시오
# //
# //세수를 입력받아 큰수를 출력하시오
# //
# //두수를 입력 받아 큰 수가 짝수이면 출력하시오
# //
# //두수를 입력 받아 합이 짝수이고 3의 배수인 수를 출력하시오

