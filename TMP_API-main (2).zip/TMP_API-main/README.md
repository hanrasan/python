# 01 KAKAOLOGIN
- Kakao.Auth.loginForm() 
- Kakao.Auth.logout()
- Kakao.API.Request() 

# 02 KAKAO_MAP_API
- Daum 주소 API
- Kakao 지도 API

# 03 KAKAO_GITPAGE
- 01,02 js 파일과 github.io page 연결해보기
- [수정] kakao_auth.js 파일의 location.href 경로를 상대경로로 수정
- [수정] index.html,main.html 파일 script src 경로를 상대경로로 수정
